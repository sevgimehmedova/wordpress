<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}


define('AUTH_KEY',         'TaYnpI1FlQ4EpHwNVZJxRlNXilW6zQsS0pA2HNj4WLHQyUl4Rkx24ncIVSjV+Hx2FpVFYmE403TomaUJImEO/g==');
define('SECURE_AUTH_KEY',  'GM7iqT1tc3zgcZ49y1m6bgbVVvPp9AJbCYYCqDsKmQJmyWVs/yHSEMQkisrUj+paY7deZpSZgBNxUapb6t5Hpg==');
define('LOGGED_IN_KEY',    '8KbDU+IItFXWRAasC0bTGgo8NyyzE6nEdWRnvGWfV5ExKMuVuh5x79oTfmblfBcsJeX88rUgESggAOXm6uv0kA==');
define('NONCE_KEY',        'PzxUJeKPHBm0hrcBh7Pl2QRQi1+sJhcrKxvh92+AElTFbKYsNXE+J3gGX5CGf1pCSixkhDagjZ84UqoP1YOQZg==');
define('AUTH_SALT',        'QYmT2GbkyXVb0/7iJZ8TjK6CMeBzCmi4LshIqscfcveNVCu2jeDZdlFPWbTTU389BiEo5qrNNmCrsEEErG2nwA==');
define('SECURE_AUTH_SALT', 'Mfc0LRCZT+LcvwcAAGKM160wV2NYOX9bnTJS3IiPcZ4yRve1rIacVXfmXKr6qP2mu5p155nmhP9VAzxW0l7qug==');
define('LOGGED_IN_SALT',   '4oM118ULy1MbmmLZiPXm+HQkMENySg72MAKBpYW8O8ZEmcphYtTp4fLBTFV0GfecjmLDmKdubBednTRogF/bVQ==');
define('NONCE_SALT',       'JkTJS7mqr3xOpE+WV4r3Qm68YAvRaxCTokAaBLNy0ZnMZj3dzqwq0WH+Nt0ZvRBAXkQEmYJoRyrYMn3ijZCWDA==');
define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
